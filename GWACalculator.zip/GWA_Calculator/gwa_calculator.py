#!/usr/bin/env python3
"""
GWA Calculator - Reads grades from a PDF and computes General Weighted Average.
"""

import subprocess
import sys
import time
import re
import os


# ── Auto-install dependencies ────────────────────────────────────────────────
def ensure_dependencies():
    try:
        from pypdf import PdfReader  # noqa: F401
    except ImportError:
        print("[*] pypdf not found. Installing...")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "pypdf", "--quiet"],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            print(f"[!] Failed to install pypdf:\n{result.stderr}")
            input("\nPress Enter to exit...")
            sys.exit(1)
        print("[+] pypdf installed successfully.\n")

ensure_dependencies()
from pypdf import PdfReader  # noqa: E402


# ── Change working directory to script location ──────────────────────────────
os.chdir(os.path.dirname(os.path.abspath(__file__)))


# ── List PDFs in current folder ──────────────────────────────────────────────
def list_pdfs() -> list:
    return [f for f in os.listdir(".") if f.lower().endswith(".pdf")]


# ── Grade calculation ────────────────────────────────────────────────────────
def calculate_grade(student_grades: dict) -> None:
    if not student_grades:
        print("\n[!] No grades were extracted from the PDF.")
        print("    Possible reasons:")
        print("    - The PDF uses a scanned image (not selectable text)")
        print("    - The format does not match the expected layout")
        print("    - No subjects with grades were found")
        return

    data = []
    skipped = []

    for key, values in student_grades.items():
        subject = values.get("subject", "Unknown")
        try:
            unit = float(values["unit"])
            grade = float(values["grade"])
            data.append((subject, unit, grade))
        except (KeyError, ValueError) as e:
            skipped.append((subject, str(e)))

    if skipped:
        print("\n[!] Skipped entries due to invalid data:")
        for subj, reason in skipped:
            print(f"    - {subj}: {reason}")

    if not data:
        print("\n[!] No valid grade entries to compute GWA.")
        return

    print("\n" + "=" * 55)
    print(f"  {'SUBJECT':<35} {'GRADE':>5}  {'UNITS':>5}")
    print("=" * 55)
    for subject, unit, grade in data:
        print(f"  {subject:<35} {grade:>5.2f}  {unit:>5.1f}")
    print("=" * 55)

    numer = sum(g * u for _, u, g in data)
    denom = sum(u for _, u, _ in data)

    if denom == 0:
        print("[!] Total units is 0 - cannot compute GWA.")
        return

    gwa = numer / denom

    print()
    print("###################################################")
    print("  PLEASE DOUBLE CHECK [Grades], [Units], [Subjects]")
    print("  Make sure all subjects have grades")
    print("###################################################")

    while True:
        confirm = input("\nIs all the info above correct? [y/n]: ").strip().lower()
        if confirm == "y":
            break
        elif confirm == "n":
            print("\n[!] Cancelled. Please check your PDF and try again.")
            return
        else:
            print("    Please type  y  for yes  or  n  for no.")

    print("Starting Calculation now.....")
    time.sleep(4)
    print("Performing arithmetic...")
    time.sleep(1)
    print("Using my 100% power for better accuracy...")
    time.sleep(3)
    print("hello world!")
    time.sleep(1)
    print("Just kidding, your gpa is...")
    time.sleep(2)
    print(f"Your GWA: {round(gwa,3)} ")
    print("=" * 55)


# ── PDF processing ───────────────────────────────────────────────────────────
def process_pdf(file: str) -> None:
    # Build full path relative to script directory
    filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), file)

    if not os.path.exists(filepath):
        print(f"\n[!] File not found: '{file}'")
        print(f"    Looking in: {os.path.dirname(os.path.abspath(__file__))}")
        print("    Make sure the PDF is in the SAME FOLDER as this script.")
        return

    print(f"\n[*] Reading '{file}'...")

    try:
        reader = PdfReader(filepath)
    except Exception as e:
        print(f"\n[!] Could not open PDF: {e}")
        print("    The file may be corrupted, password-protected, or not a valid PDF.")
        return

    if len(reader.pages) == 0:
        print("\n[!] The PDF has no pages.")
        return

    text = ""
    for i, page in enumerate(reader.pages):
        try:
            extracted = page.extract_text()
            if extracted:
                text += extracted
        except Exception as e:
            print(f"    [!] Could not read page {i + 1}: {e}")

    if not text.strip():
        print("\n[!] No text could be extracted from the PDF.")
        print("    This PDF may be a scanned image. Try an OCR tool first.")
        return

    lines = " ".join(text.split())

    pattern = (
        r"(?P<code>CE\d+)\s+([\w\- ]+?)\s+"
        r"(?P<subject>[A-Z]+[ ,\w/:\-\)\(]+\d{0,1})"
        r"\s+(?P<unit>[.\d]{3,4})"
        r"\s+(\d{2}:\d{2}(?:AM|PM)-\d{2}:\d{2}(?:AM|PM))"
        r"\s+([A-Za-z]+)\s+([A-Za-z. ]*[\d]{0,3}\s+"
        r"(?=(?P<grade>\d{1}\.\d{1,2})))"
    )

    student_grades = {}
    for idx, match in enumerate(re.finditer(pattern, lines)):
        student_grades[idx] = {
            "subject": match.group("subject"),
            "unit":    match.group("unit"),
            "grade":   match.group("grade"),
        }

    print(f"[+] Found {len(student_grades)} subject(s).\n")
    calculate_grade(student_grades)


# ── Entry point ──────────────────────────────────────────────────────────────
def main():
    print("╔═══════════════════════════════════╗")
    print("║       GWA Calculator v1.0         ║")
    print("╚═══════════════════════════════════╝")
    print(f"  Folder: {os.path.dirname(os.path.abspath(__file__))}")
    print()

    while True:
        # Show available PDFs so user knows what to type
        pdfs = list_pdfs()
        if pdfs:
            print("  PDFs found in this folder:")
            for i, name in enumerate(pdfs, 1):
                print(f"    [{i}] {name}")
            print()
            print("  You can type the filename  OR  type a number from the list above.")
            print("  Type  q  to quit.")
            print()
        else:
            print("  [!] No PDF files found in this folder.")
            print(f"      Put your PDF here: {os.path.dirname(os.path.abspath(__file__))}")
            print("      Then press Enter to refresh, or type  q  to quit.")
            print()

        choice = input("  Enter choice: ").strip()
        print()

        if choice.lower() == "q":
            print("  Goodbye!")
            break

        if not choice:
            continue  # Refresh the list

        # Allow selecting by number
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(pdfs):
                file = pdfs[idx]
                print(f"  Selected: {file}")
            else:
                print(f"  [!] Invalid number. Please pick between 1 and {len(pdfs)}.")
                continue
        else:
            file = choice
            if not file.lower().endswith(".pdf"):
                file += ".pdf"

        process_pdf(file)

        print()
        again = input("  Calculate another? [y/n]: ").strip().lower()
        print()
        if again != "y":
            print("  Goodbye!")
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  Interrupted. Goodbye!")
        sys.exit(0)
    finally:
        input("\nPress Enter to close...")

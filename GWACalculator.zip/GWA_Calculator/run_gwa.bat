@echo off
cd /d "%~dp0"
python gwa_calculator.py
